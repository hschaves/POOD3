package ExemploClasseUsuario;

public class TesteUsuario {

	public static void main(String[] args) {
		Usuario usuario= new Usuario(0, "asdfg@lkjjff", "1", 1, "ssssssss", "45464646464", null, null, null, null, null, null, null, null);
		usuario.save();
	}
	
}
