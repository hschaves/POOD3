package module;

public class TesteInstitucional {

	public static void main(String[] args) {
		Institucional institucional= new Institucional(0,"ssssssss","12345678910","F", "", "", "", "", "", "", "");
		institucional.save();
	}
}