package module;

import database.DBQuery;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Institucional {
	
	private int    idInstitucional;
	private String nome;
	private String cpf_cnpj;
	private String tipoPessoa;
	private String endereco;
	private String bairro;
	private String cidade;
	private String uf;
	private String cep;
	private String telefone;
	private String email;
	private String logo;
	
	private String tableName 	= "institucional";
	private String fieldsName 	= "idInstitucional, nome, cpf_cnpf, tipoPessoa, endereco, bairro, cidade, uf, cep, telefone, email, logo";
	private String fieldKey  	= "idInstituicao";
	private DBQuery dbQuery     = new DBQuery(tableName, fieldsName, fieldKey);
	
	public Institucional( ) {
	
	}

	public Institucional ( int idInstitucional, String nome, String cpf_cnpf, String tipoPessoa, String endereco, String bairro, String cidade, String uf, String telefone, String email, String logo) {
		this.setIdInstitucional(idInstitucional);
		this.setNome(nome);
		this.setCpf_cnpj(cpf_cnpf);
		this.setTipoPessoa(tipoPessoa);
		this.setEndereco(endereco);
		this.setBairro(bairro);
		this.setCidade(cidade);
		this.setUf(uf);
		this.setCep(cep);
		this.setTelefone(telefone);
		this.setEmail(email);
		this.setLogo(logo);
	}

	public String[] toArray() {
		// deve ser na mesma ordem que informado no fieldsName
		String[] values = new String[] {
				this.getIdInstitucional() + "",
				this.getNome(),
				this.getCpf_cnpj(),
				this.getTipoPessoa()+"",
				this.getEndereco(),
				this.getBairro(),
				this.getCidade(),
				this.getUf(),
				this.getCep(),
				this.getCep(),
				this.getEmail(),
				this.getLogo(), 
		};
		return (values);
	}
	
	public void listAll() {
		ResultSet rs = this.dbQuery.select("");
		try {
			while (rs.next()) {
				String out = "";
				out += rs.getString("idInstituicao") + "|";
				out += rs.getString("nome") + "|";
				out += rs.getString("cpf_cnpj") + "|";
				out += rs.getString("tipoPessoa") + "|";
				out += rs.getString("endereco") + "|";
				out += rs.getString("bairro") + "|";
				out += rs.getString("cidade") + "|";
				out += rs.getString("uf") + "|";
				out += rs.getString("cep") + "|";
				out += rs.getString("telefone") + "|";
				out += rs.getString("email") + "|";
				out += rs.getString("logo");
				System.out.println(  out );
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void save () {
		if ( this.getIdInstitucional() == 0) {
			this.dbQuery.insert(this.toArray());
		} else {
			this.dbQuery.update(this.toArray());
		}
	}
	
	public void delete() {
		if ( this.getIdInstitucional() != 0) {
			this.dbQuery.delete(this.toArray());
		}
	}
	
	public int getIdInstitucional() {
		return idInstitucional;
	}

	public void setIdInstitucional(int idInstitucional) {
		this.idInstitucional = idInstitucional;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf_cnpj() {
		return cpf_cnpj;
	}

	public void setCpf_cnpj(String cpf_cnpj) {
		this.cpf_cnpj = cpf_cnpj;
	}

	public String getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}


}
