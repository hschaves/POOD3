package herancaExemplo;

public class Teste {
	public static void main(String[] args) {
		new AncestralFrame();
		new HerancaFrame();
	}
}
