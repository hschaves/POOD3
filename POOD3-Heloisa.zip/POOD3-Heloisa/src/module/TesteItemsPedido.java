package module;

public class TesteItemsPedido {
	public static void main(String[] args) {
		ItemsPedido itemsPedido= new ItemsPedido(0, 1, 1, 2, 1, 2, "");
		itemsPedido.save();
	}
}
