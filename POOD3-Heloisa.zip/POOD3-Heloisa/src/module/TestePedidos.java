package module;

public class TestePedidos {
	public static void main(String[] args) {
		Pedidos pedidos= new Pedidos(0, 0, "", "", "", "", "", "", 0 , "", "", "", "", "", "", "", "", "", "", "", 0, "", "");   
		pedidos.save();
	}
}
