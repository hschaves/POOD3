package module;

import java.sql.ResultSet;
import java.sql.SQLException;
import database.DBQuery;

public class NivelUsuarios {
	
	private int    idNivelUsuario;
	private String nivel;

	private String tableName 	= "nivelUsuarios";
	private String fieldsName 	= "idNivelUsuario, nivel";
	private String fieldKey  	= "idNivelUsuario";
	private DBQuery dbQuery     = new DBQuery(tableName, fieldsName, fieldKey);

	public NivelUsuarios(){
	
	}

	public NivelUsuarios( int idNivelUsuario, String nivel ) {
		this.setIdNivelUsuario(idNivelUsuario);
		this.setNivel(nivel);
	}
	
	public String[] toArray() {
		// deve ser na mesma ordem que informado no fieldsName
		String[] values = new String[] {
				this.getIdNivelUsuario() + "",
				this.getNivel(),
		};
		return (values);
	}
	
	
	public void listAll() {
		ResultSet rs = this.dbQuery.select("");
		try {
			while (rs.next()) {
				String out = "";
				out += rs.getString("idNivelUsuario") + "|";
				out += rs.getString("nivel");
				System.out.println(  out );
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void save () {
		if ( this.getIdNivelUsuario() == 0) {
			this.dbQuery.insert(this.toArray());
		} else {
			this.dbQuery.update(this.toArray());
		}
	}
	
	public void delete() {
		if ( this.getIdNivelUsuario() != 0) {
			this.dbQuery.delete(this.toArray());
		}
	}

	public int getIdNivelUsuario() {
		return idNivelUsuario;
	}

	public void setIdNivelUsuario(int idNivelUsuario) {
		this.idNivelUsuario = idNivelUsuario;
	}

	public String getNivel() {
		return nivel;
	}

	public void setNivel(String nivel) {
		this.nivel = nivel;
	}

}