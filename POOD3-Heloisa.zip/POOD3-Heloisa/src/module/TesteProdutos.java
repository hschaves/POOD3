package module;

public class TesteProdutos {
	public static void main(String[] args) {
		Produtos produto= new Produtos(0, "", "", "", "", 1, "", "", 3, 3, 1, 40, "");
		produto.save();
	}
}
