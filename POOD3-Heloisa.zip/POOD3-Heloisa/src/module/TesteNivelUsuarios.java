package module;

public class TesteNivelUsuarios {
	public static void main(String[] args) {
		NivelUsuarios nivelUsuarios = new NivelUsuarios(0, "");
		nivelUsuarios.save();
	}
}
