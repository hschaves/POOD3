package module;

public class TesteEstoque {
	public static void main(String[] args) {
		Estoque estoque= new Estoque(0 ,0 ,"" ,0 ,"" ,"" ,"" ,"" ,"" ,"" ,0 ,0 ,"");
		estoque.save();
	}
}
   