package module;

public class TesteInstitucional {

	public static void main(String[] args) {
		Institucional institucional= new Institucional(1, "teste", "", "", "", "", "", "", "", "", "", "");
		institucional.save();
	}
}