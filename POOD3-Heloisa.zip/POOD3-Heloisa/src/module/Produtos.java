package module;

import database.DBQuery;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Produtos {

	private int    idProduto;
	private String fabricante;
	private String nome;
	private String marca;
	private String modelo;
	private int    idCategoria;
	private String descricao;
	private String unidadeMedida;
	private int  largura;
	private int  altura;
	private int  profundidade;
	private int  peso;
	private String cor;
	
	private String tableName 	= "produtos";
	private String fieldsName 	= "idProduto, fabricante, nome, marca, modelo, idCategoria, descricao, unidadeMedida, largura, altura, profundidade, peso, cor";
	private String fieldKey  	= "idProduto";
	private DBQuery dbQuery     = new DBQuery(tableName, fieldsName, fieldKey);
	
	public Produtos( ) {
	
	}

	public Produtos( int idProduto, String fabricante, String nome, String marca, String modelo, int idCategoria, String descricao, String unidadeMedida, int largura, int altura, int profundidade, int peso, String cor ) {
		this.setIdProduto(idProduto);
		this.setFabricante(fabricante);
		this.setNome(nome);
		this.setMarca(marca);
		this.setModelo(modelo);
		this.setIdCategoria(idCategoria);
		this.setDescricao(descricao);
		this.setUnidadeMedida(unidadeMedida);
		this.setLargura(largura);
		this.setAltura(altura);
		this.setProfundidade(profundidade);
		this.setPeso(peso);
		this.setCor(cor);
	}
	
	public String[] toArray() {
		// deve ser na mesma ordem que informado no fieldsName
		String[] values = new String[] {
				this.getIdProduto() + "",
				this.getFabricante(),
				this.getNome(),
				this.getMarca(),
				this.getModelo(),
				this.getIdCategoria()+ "",
				this.getDescricao(),
				this.getUnidadeMedida(),
				this.getLargura()+ "",
				this.getAltura()+ "",
				this.getProfundidade()+ "",
				this.getPeso()+ "",
				this.getCor(),
		};
		return (values);
	}
	
	
	public String getUnidadeMedida() {
		return unidadeMedida;
	}

	public void setUnidadeMedida(String unidadeMedida) {
		this.unidadeMedida = unidadeMedida;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public void listAll() {
		ResultSet rs = this.dbQuery.select("");
		try {
			while (rs.next()) {
				String out = "";
				out += rs.getString("idProduto") + "|";
				out += rs.getString("fabricante") + "|";
				out += rs.getString("nome") + "|";
				out += rs.getString("marca") + "|";
				out += rs.getString("modelo") + "|";
				out += rs.getString("idCategoria") + "|";
				out += rs.getString("descricao") + "|";
				out += rs.getString("unidadeMedida") + "|";
				out += rs.getString("largura") + "|";
				out += rs.getString("altura") + "|";
				out += rs.getString("profundidade") + "|";
				out += rs.getString("peso")+ "|";
				out += rs.getString("cor");
				System.out.println(  out );
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void save () {
		if ( this.getIdProduto() == 0) {
			this.dbQuery.insert(this.toArray());
		} else {
			this.dbQuery.update(this.toArray());
		}
	}
	
	public void delete() {
		if ( this.getIdProduto() != 0) {
			this.dbQuery.delete(this.toArray());
		}
	}

	public int getIdProduto() {
		return idProduto;
	}

	public void setIdProduto(int idProduto) {
		this.idProduto = idProduto;
	}

	public String getFabricante() {
		return fabricante;
	}

	public void setFabricante(String fabricante) {
		this.fabricante = fabricante;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public int getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public int getLargura() {
		return largura;
	}

	public void setLargura(int largura) {
		this.largura = largura;
	}

	public int getProfundidade() {
		return profundidade;
	}

	public void setProfundidade(int profundidade) {
		this.profundidade = profundidade;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}
}
