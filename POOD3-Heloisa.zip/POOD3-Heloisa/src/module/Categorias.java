package module;

import database.DBQuery;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Categorias {
	
	private int    idCategoria;
	private String descricao;
	
	private String tableName 	= "categorias";
	private String fieldsName 	= "idCategoria, descricao";
	private String fieldKey  	= "idCategoria";
	private DBQuery dbQuery     = new DBQuery(tableName, fieldsName, fieldKey);
	
	public Categorias(){
	
	}

	public Categorias(int idCategoria, String descricao) {
		this.setIdCategoria(idCategoria);
		this.setDescricao(descricao);
	}

	public String[] toArray() {
		// deve ser na mesma ordem que informado no fieldsName
		String[] values = new String[] {
				this.getIdCategoria() + "",
				this.getDescricao(),
		};
		return (values);
	}
	
	public void listAll() {
		ResultSet rs = this.dbQuery.select("");
		try {
			while (rs.next()) {
				String out = "";
				out += rs.getString("idCategoria") + "|";
				out += rs.getString("descricao");
				System.out.println(  out );
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void save () {
		if ( this.getIdCategoria() == 0) {
			this.dbQuery.insert(this.toArray());
		} else {
			this.dbQuery.update(this.toArray());
		}
	}
	
	public void delete() {
		if ( this.getIdCategoria() != 0) {
			this.dbQuery.delete(this.toArray());
		}
	}
	
	public int getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
}

