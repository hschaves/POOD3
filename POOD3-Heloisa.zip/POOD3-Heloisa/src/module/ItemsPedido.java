package module;

import database.DBQuery;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ItemsPedido {

	private int    idItemPedido;
	private int    ordem;
	private int    idPedido;
	private int    idEstoque;
	private int    qtdItem;
	private int    dtDevolucao;
	private String motivoDevolucao;

	private String tableName 	= "itemspedido";
	private String fieldsName 	= "idItemPedido, ordem, idPedido, idEstoque, qtdItem, dtDevolucao, motivoDevolucao";
	private String fieldKey  	= "idItemPedido";
	private DBQuery dbQuery     = new DBQuery(tableName, fieldsName, fieldKey);
	
	public ItemsPedido(){
	
	}

	public ItemsPedido(int idItemPedido, int ordem, int idPedido, int idEstoque, int qtdItem, int dtDevolucao, String motivoDevolucao) {
		this.setIdItemPedido(idItemPedido);
		this.setOrdem(ordem);
		this.setIdPedido(idPedido);
		this.setIdEstoque(idEstoque);
		this.setQtdItem(qtdItem);
		this.setDtDevolucao(dtDevolucao);
		this.setMotivoDevolucao(motivoDevolucao);
	}
	
	public String[] toArray() {
		// deve ser na mesma ordem que informado no fieldsName
		String[] values = new String[] {
				this.getIdItemPedido() + "",
				this.getOrdem() + "",
				this.getIdPedido() + "",
				this.getIdEstoque()+"",
				this.getQtdItem() + "",
				this.getDtDevolucao() + "",
				this.getMotivoDevolucao(),
		};
		return (values);
	}
	
	
	public void listAll() {
		ResultSet rs = this.dbQuery.select("");
		try {
			while (rs.next()) {
				String out = "";
				out += rs.getString("idItemPedido") + "|";
				out += rs.getString("ordem") + "|";
				out += rs.getString("idPedido") + "|";
				out += rs.getString("idEstoque") + "|";
				out += rs.getString("qtdItem") + "|";
				out += rs.getString("dtDevolucao") + "|";
				out += rs.getString("motivoDevolucao");
				System.out.println(  out );
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void save () {
		if ( this.getIdItemPedido() == 0) {
			this.dbQuery.insert(this.toArray());
		} else {
			this.dbQuery.update(this.toArray());
		}
	}
	
	public void delete() {
		if ( this.getIdItemPedido() != 0) {
			this.dbQuery.delete(this.toArray());
		}
	}

	public int getIdItemPedido() {
		return idItemPedido;
	}

	public void setIdItemPedido(int idItemPedido) {
		this.idItemPedido = idItemPedido;
	}

	public int getOrdem() {
		return ordem;
	}

	public void setOrdem(int ordem) {
		this.ordem = ordem;
	}

	public int getIdPedido() {
		return idPedido;
	}

	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}

	public int getIdEstoque() {
		return idEstoque;
	}

	public void setIdEstoque(int idEstoque) {
		this.idEstoque = idEstoque;
	}

	public int getQtdItem() {
		return qtdItem;
	}

	public void setQtdItem(int qtdItem) {
		this.qtdItem = qtdItem;
	}

	public int getDtDevolucao() {
		return dtDevolucao;
	}

	public void setDtDevolucao(int dtDevolucao) {
		this.dtDevolucao = dtDevolucao;
	}

	public String getMotivoDevolucao() {
		return motivoDevolucao;
	}

	public void setMotivoDevolucao(String motivoDevolucao) {
		this.motivoDevolucao = motivoDevolucao;
	}
}