package module;

import database.DBQuery;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Estoque {
	
	private int    idEstoque;
	private int    idProduto;
	private String dtEntrada;
	private int    quantidade;
	private String dtFabricacao;
	private String dtVencimento;
	private String nfCompra;
	private String precoCompra;
	private String icmsCompra;
	private String precoVenda;
	private int    qtdVendida;
	private int    qtdOcorrencia;
	private String ocorrencia;
	
	private String tableName 	= "estoque";
	private String fieldsName 	= "idEstoque, idProduto, dtEntrada, quantidade, dtFabricacao, dtVencimento, nfCompra, precoCompra, icmsCompra, precoVenda, qtdVendida, qtdOcorrencia, ocorrencia";
	private String fieldKey  	= "idEstoque";
	private DBQuery dbQuery     = new DBQuery(tableName, fieldsName, fieldKey);
	
	public Estoque( ) {
	
	}

	public Estoque(int idEstoque ,int idProduto ,String dtEntrada ,int quantidade,String dtFabricacao ,String dtVencimento ,String nfCompra ,String precoCompra ,String icmsCompra ,String precoVenda ,int qtdVendida ,int qtdOcorrencia ,String ocorrencia) {
		this.setIdEstoque(idEstoque);
		this.setIdProduto(idProduto);
		this.setDtEntrada(dtEntrada);
		this.setQuantidade(quantidade);
		this.setDtFabricacao(dtFabricacao);
		this.setDtVencimento(dtVencimento);
		this.setNfCompra(nfCompra);
		this.setPrecoCompra(precoCompra);
		this.setIcmsCompra(icmsCompra);
		this.setPrecoVenda(precoVenda);
		this.setQtdVendida(qtdVendida);
		this.setQtdOcorrencia(qtdOcorrencia);
		this.setOcorrencia(ocorrencia);
	}

	public String[] toArray() {
		// deve ser na mesma ordem que informado no fieldsName
		String[] values = new String[] {
				this.getIdEstoque() + "",
				this.getIdProduto() + "",
				this.getDtEntrada() ,
				this.getQuantidade() + "",
				this.getDtFabricacao() ,
				this.getDtVencimento() ,
				this.getNfCompra() ,
				this.getPrecoCompra() ,
				this.getIcmsCompra() ,
				this.getPrecoVenda() ,
				this.getQtdVendida() + "",
				this.getQtdOcorrencia() + "",
				this.getOcorrencia() ,
		};
		return (values);
	}
	
	public void listAll() {
		ResultSet rs = this.dbQuery.select("");
		try {
			while (rs.next()) {
				String out = "";
				out += rs.getString("idEstoque") + "|";
				out += rs.getString("idProduto") + "|";
				out += rs.getString("dtEntrada") + "|";
				out += rs.getString("quantidade") + "|";
				out += rs.getString("dtFabricacao") + "|";
				out += rs.getString("dtVencimento") + "|";
				out += rs.getString("nfCompra") + "|";
				out += rs.getString("precoCompra") + "|";
				out += rs.getString("icmsCompra") + "|";
				out += rs.getString("precoVenda") + "|";
				out += rs.getString("qtdVendida") + "|";
				out += rs.getString("qtdOcorrencia") + "|";
				out += rs.getString("ocorrencia");
				System.out.println(  out );
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void save () {
		if ( this.getIdEstoque() == 0) {
			this.dbQuery.insert(this.toArray());
		} else {
			this.dbQuery.update(this.toArray());
		}
	}
	
	public int getIdEstoque() {
		return idEstoque;
	}

	public void setIdEstoque(int idEstoque) {
		this.idEstoque = idEstoque;
	}

	public int getIdProduto() {
		return idProduto;
	}

	public void setIdProduto(int idProduto) {
		this.idProduto = idProduto;
	}

	public String getDtEntrada() {
		return dtEntrada;
	}

	public void setDtEntrada(String dtEntrada) {
		this.dtEntrada = dtEntrada;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public String getDtFabricacao() {
		return dtFabricacao;
	}

	public void setDtFabricacao(String dtFabricacao) {
		this.dtFabricacao = dtFabricacao;
	}

	public String getDtVencimento() {
		return dtVencimento;
	}

	public void setDtVencimento(String dtVencimento) {
		this.dtVencimento = dtVencimento;
	}

	public String getNfCompra() {
		return nfCompra;
	}

	public void setNfCompra(String nfCompra) {
		this.nfCompra = nfCompra;
	}

	public String getPrecoCompra() {
		return precoCompra;
	}

	public void setPrecoCompra(String precoCompra) {
		this.precoCompra = precoCompra;
	}

	public String getIcmsCompra() {
		return icmsCompra;
	}

	public void setIcmsCompra(String icmsCompra) {
		this.icmsCompra = icmsCompra;
	}

	public String getPrecoVenda() {
		return precoVenda;
	}

	public void setPrecoVenda(String precoVenda) {
		this.precoVenda = precoVenda;
	}

	public int getQtdVendida() {
		return qtdVendida;
	}

	public void setQtdVendida(int qtdVendida) {
		this.qtdVendida = qtdVendida;
	}

	public int getQtdOcorrencia() {
		return qtdOcorrencia;
	}

	public void setQtdOcorrencia(int qtdOcorrencia) {
		this.qtdOcorrencia = qtdOcorrencia;
	}

	public String getOcorrencia() {
		return ocorrencia;
	}

	public void setOcorrencia(String ocorrencia) {
		this.ocorrencia = ocorrencia;
	}

	public void delete() {
		if ( this.getIdEstoque() != 0) {
			this.dbQuery.delete(this.toArray());
		}
	}
	
}
	
	