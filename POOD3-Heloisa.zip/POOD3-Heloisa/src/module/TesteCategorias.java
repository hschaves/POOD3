package module;

public class TesteCategorias {
	public static void main(String[] args) {
		Categorias categorias= new Categorias(0 ,"");
		categorias.save();
	}
}